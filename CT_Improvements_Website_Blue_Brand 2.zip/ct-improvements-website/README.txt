CT IMPROVEMENTS LLC WEBSITE — BLUE / BLACK BRAND VERSION

The website uses your supplied CT logo and promotional graphics.
Files:
- index.html
- assets/ct-logo.jpg
- assets/brand-banner.jpg
- assets/business-promo.jpg

FREE HOSTING WITH GITHUB PAGES
1. Create a free account at https://github.com/
2. Create a public repository named ct-improvements-website
3. Upload index.html and the entire assets folder.
4. Open repository Settings > Pages.
5. Under Build and deployment, select Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. GitHub will display your free published website address.

The quote form prepares a text message to 716-249-8479; visitors review and send it.
A custom .com domain is optional and costs extra. GitHub Pages hosting is free.
Please verify all claims and details before publishing.
